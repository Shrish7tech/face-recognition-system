package com.fis.BankingApplication.model;

import javax.persistence.Entity;

@Entity
public class Transaction {
   private Accounts acc;
   private double amount;
   private String transDate;
   private String transType;
   
   
public Transaction(Accounts acc, double amount, String transDate, String transType) {
	super();
	this.acc = acc;
	this.amount = amount;
	this.transDate = transDate;
	this.transType = transType;
}


public Accounts getAcc() {
	return acc;
}


public void setAcc(Accounts acc) {
	this.acc = acc;
}


public double getAmount() {
	return amount;
}


public void setAmount(double amount) {
	this.amount = amount;
}


public String getTransDate() {
	return transDate;
}


public void setTransDate(String transDate) {
	this.transDate = transDate;
}


public String getTransType() {
	return transType;
}


public void setTransType(String transType) {
	this.transType = transType;
}
   
   
   public Transaction()
   {
	   
   }
   
}
