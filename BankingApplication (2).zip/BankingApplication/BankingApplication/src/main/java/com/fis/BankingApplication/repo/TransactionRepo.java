package com.fis.BankingApplication.repo;

public interface TransactionRepo {

	public abstract String withdrawFromBalance(long acc, double withdrawAmount);

	public abstract String depositIntoBalance(long acc, double depositAmount);
	
	public abstract String FundTransfer(long accFrom,long accTo, double amount);
}
