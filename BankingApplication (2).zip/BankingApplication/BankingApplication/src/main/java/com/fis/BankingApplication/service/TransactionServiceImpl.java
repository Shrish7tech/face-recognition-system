package com.fis.BankingApplication.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.BankingApplication.repo.TransactionRepo;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepo trepo;
	@Override
	public String withdrawFromBalance(long acc, double withdrawAmount) {
		// TODO Auto-generated method stub
		return trepo.withdrawFromBalance(acc, withdrawAmount);
	}

	@Override
	public String depositIntoBalance(long acc, double depositAmount) {
		// TODO Auto-generated method stub
		return trepo.depositIntoBalance(acc, depositAmount);

	}

	@Override
	public String FundTransfer(long accFrom, long accTo, double amount) {
		// TODO Auto-generated method stub
		trepo.FundTransfer(accFrom, accTo, amount);
		return "FundTranfer done";
	}

}
