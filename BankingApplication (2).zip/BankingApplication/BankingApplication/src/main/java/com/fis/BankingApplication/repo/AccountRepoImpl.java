package com.fis.BankingApplication.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.BankingApplication.model.Accounts;


@Repository
public class AccountRepoImpl implements AccountRepo{
    @PersistenceContext
	EntityManager entityManager;
    
	@Override
	public String addAccount(Accounts account) {
		entityManager.persist(account);
		
		return "Account Added Successfully";
	}

	@Override
	public Accounts getAccount(long accNo) {
		// TODO Auto-generated method stub	
		
		//TypedQuery<Accounts> query1=entityManager.createQuery("Select a from Accounts a where acc_No=accNo",Accounts.class);
		return entityManager.find(Accounts.class, accNo);
	}

	@Override
	public List<Accounts> getAllAccount() {
		// TODO Auto-generated method stub
		TypedQuery<Accounts> query =entityManager.createQuery("Select a from Accounts a",Accounts.class);
		return query.getResultList();
	}

	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String updateAccount(Accounts acc) {
		// TODO Auto-generated method stub
		entityManager.merge(acc);
		return "Account Updated Successfully";
	
	}

	@Override
	public String deleteAccount(int accNo) {
		// TODO Auto-generated method stub
		entityManager.remove(getAccount(accNo));
		return "Deleted";
	
	}

	@Override
	public List<Accounts> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		// TODO Auto-generated method stub
		TypedQuery<Accounts> query = entityManager.createQuery(
				"SELECT a FROM Account a WHERE a.balance >= :minBal AND a.balance <= :maxBal",Accounts.class);
				query.setParameter("minBal",minBal);
				query.setParameter("maxBal",maxBal);
				return query.getResultList();
	}
}

	