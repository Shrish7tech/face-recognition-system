package com.fis.BankingApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.BankingApplication.service.TransactionService;


@RestController
@RequestMapping("/transactions") 
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	
	@PostMapping("/deposit/{accountId}")   //http:localhost:8080/transactions/deposit/103
	public String depositAmount(
			@PathVariable("accountId") int acc,
			@RequestParam double depositAmount
			) {
		//String transaction = 
		transactionService.depositIntoBalance(acc, depositAmount);
		return "Transaction Deposite Done";
	}
	
	@PostMapping("/withdraw/{accountId}")   //http:localhost:8080/transactions/withdraw/103
	public String withdrawAmount(
			@PathVariable("accountId") int accountId,
			@RequestParam double amount
			) {
		String transaction = transactionService.withdrawFromBalance(accountId, amount);
		return "Transaction Withdraw Done";
	}
	
	@PostMapping("/fundtransfer/{fromAccount}/{toAccount}")  //http:localhost:8080/transactions/fundtransfer/103/101
	public String fundTransferAmount(
			@PathVariable("fromAccount") int fromAccount,
			@PathVariable("toAccount") int toAccount,
			@RequestParam double amount
			) {
		String transaction = transactionService.FundTransfer(fromAccount, toAccount, amount);
		return "Transaction Fund Transfer Done";
	}
	
	/*@GetMapping("/getAllTransaction")
	public List<Transaction> getAllTransaction(){
		return transactionService.getAllTranscation();
	}
	
	@GetMapping("/getAllTransactionByAccountId/{fromAccount}")
	public List<Transaction> getAllTransactionByAccountId(
			@PathVariable("fromAccount") int fromAccount
			){
		return transactionService.getAllTranscationByAccountId(fromAccount);
	}
	*/
}
