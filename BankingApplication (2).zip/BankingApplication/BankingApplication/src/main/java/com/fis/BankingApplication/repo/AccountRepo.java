package com.fis.BankingApplication.repo;

import java.util.List;

import com.fis.BankingApplication.model.Accounts;

import com.fis.productmanagement.model.Product;

public interface AccountRepo {
	
	public abstract String addAccount(Accounts account);

	public abstract Accounts getAccount(long accNo);

	public abstract List<Accounts> getAllAccount();

	public abstract String updateAccount(Accounts acc);
	
	public abstract String deleteAccount(int accNo);
	
	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount);

	public abstract void depositIntoBalance(long getAcc, double depositAmount);
	
	public abstract List<Accounts> getAllAccountsByBalanceRange (double minBal,double maxBal);
	
	
	
	
}
