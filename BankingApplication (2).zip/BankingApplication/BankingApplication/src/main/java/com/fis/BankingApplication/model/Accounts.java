package com.fis.BankingApplication.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "banking_app")
public class Accounts {
	@Id
	@Column(name="accNo")
	private long accNo;
	private String custName;
	private String email;
	private String password;
	private long mobile;
	private String accType;
	private String branch;
	private double balance;
	private long aadhar;
	private String dob;
	
	

	public long getAccNo() {
		return accNo;
	}


	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public long getMobile() {
		return mobile;
	}


	public void setMobile(long mobile) {
		this.mobile = mobile;
	}


	public String getAccType() {
		return accType;
	}


	public void setAccType(String accType) {
		this.accType = accType;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public long getAadhar() {
		return aadhar;
	}


	public void setAadhar(long aadhar) {
		this.aadhar = aadhar;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	


	public Accounts(long accNo, String custName, String email, String password, long mobile, String accType,
			String branch, double balance, long aadhar, String dob) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.email = email;
		this.password = password;
		this.mobile = mobile;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
		this.aadhar = aadhar;
		this.dob = dob;
	}



	@Override
	public String toString() {
		return "Accounts [accNo=" + accNo + ", custName=" + custName + ", email=" + email + ", password=" + password
				+ ", mobile=" + mobile + ", accType=" + accType + ", branch=" + branch + ", balance=" + balance
				+ ", aadhar=" + aadhar + ", dob=" + dob + "]";
	}


	public Accounts()
	{
		
	}

	
	
	
}
