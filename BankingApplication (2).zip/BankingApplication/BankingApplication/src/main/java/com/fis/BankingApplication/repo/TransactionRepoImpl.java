package com.fis.BankingApplication.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.BankingApplication.model.Accounts;


@Repository
public class TransactionRepoImpl implements TransactionRepo{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public String withdrawFromBalance(long accNo, double withdrawAmount) {
		// TODO Auto-generated method stub
		Accounts account=entityManager.find(Accounts.class, accNo);
		if(account!=null && withdrawAmount<account.getBalance())
		{
			double c_bal=account.getBalance();
			double u_bal=c_bal-withdrawAmount;
			account.setBalance(u_bal);
			entityManager.merge(account);
		}
	    return" Amount is Withdrawn";

	}

	@Override
	public String depositIntoBalance(long accNo, double depositAmount) {
		// TODO Auto-generated method stub
		//TypedQuery<Accounts> query =entityManager.createQuery("Select a from Accounts a",Accounts.class);
		Accounts account=entityManager.find(Accounts.class, accNo);
		if(account!=null && depositAmount>0)
		{
			double c_bal=account.getBalance();
			double u_bal=c_bal+depositAmount;
			account.setBalance(u_bal);
			entityManager.merge(account);
		}
	    return" Amount is deposited";
	}

	@Override
	public String FundTransfer(long accFrom, long accTo, double amount) {
		// TODO Auto-generated method stub
		Accounts sender = entityManager.find(Accounts.class, accFrom);
		Accounts reciver= entityManager.find(Accounts.class, accTo);
		
		double c_ReciverBal = reciver.getBalance();
		double u_ReciverBal = c_ReciverBal + amount;
		
		double c_SenderBal = sender.getBalance();
		double u_SenderBal = c_SenderBal - amount;
		
		reciver.setBalance(u_ReciverBal);
		sender.setBalance(u_SenderBal);
		
		entityManager.merge(reciver);
		entityManager.merge(sender);
		
		return "Fund is Tranferred";
		
		
	}

}
